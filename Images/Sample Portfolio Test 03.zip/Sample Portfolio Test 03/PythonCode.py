# Function to process sales data from a text file and write output to another text file
def process_sales_data(input_file, output_file):
    try:
        # Open the input file for reading and output file for writing
        with open(input_file, 'r') as infile, open(output_file, 'w') as outfile:
            
            # Read each line from the input file
            for line in infile:
                try:
                    # Split the line into date, item, quantity, and price
                    # The strip() removes extra spaces or newline characters from the ends
                    date, item, quantity, price = line.strip().split(',')
                    
                    # Convert the quantity to an integer and price to a float
                    quantity = int(quantity.strip())  # Convert quantity to integer
                    price = float(price.strip())  # Convert price to float
                    
                    # Calculate the total sales for the current record
                    total_sales = quantity * price  # Multiply quantity by price
                    
                    # Create an updated line that includes the original data plus the total sales
                    # Format the output to two decimal places for price and total sales
                    updated_line = f"{date}, {item}, {quantity}, {price:.2f}, Total: {total_sales:.2f}\n"
                    
                    # Write the updated line to the output file
                    outfile.write(updated_line)
                
                # Handle the exception if quantity or price cannot be converted to numbers
                except ValueError:
                    print(f"Invalid data in line: {line.strip()}. Skipping this line.")
    
    # Handle the exception if the input file does not exist
    except FileNotFoundError:
        print(f"Error: The file '{input_file}' was not found.")
    
    # Handle the exception if the program does not have permission to access the file
    except PermissionError:
        print(f"Error: Permission denied for accessing '{input_file}'.")

    # Catch any other exceptions and display the error message
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

# Main program loop
while True:
    # Prompt the user to enter the name of the input file
    file_name = input("Enter the name of the file with sales data: ")
    
    # Call the process_sales_data function to process the sales data
    # The output file will always be "output_sales.txt"
    process_sales_data(file_name, "output_sales.txt")
    
    # Ask the user if they want to process another file
    choice = input("Do you want to process another file? (yes/no): ").strip().lower()
    
    # If the user says 'no', break out of the loop and exit the program
    if choice == 'no':
        print("Goodbye!")
        break
